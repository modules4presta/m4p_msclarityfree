<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class Mfp_switch_invoice extends Module
{
    public function __construct()
    {
        $this->name = 'Mfp_switch_invoice';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Nice Code';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.6',
            'max' => '8.1.99',
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Switch Invoice/bill');
        $this->description = $this->l('Switch Invoice/bill in checkout');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        if (!Configuration::get('SELECT ADD')) {
            $this->warning = $this->l('No name provided');
        }
    }


    public function install()
    {

        if (!parent::install() ||
            !$this->registerHook('displayBeforePayment') ||
            !$this->registerHook('actionOrderStatusUpdate')
        ) {
            return false;
        }
        $sql_ok = true;
        $sql = array();
        $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'mfpswitchinvoicebill` (
				  `id` int(11) NOT NULL AUTO_INCREMENT,				  
				  `id_order` int(11) NOT NULL,
				  `invocie_bill` int(1) NOT NULL,			  
				  PRIMARY KEY (`id`)
				) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;';

        foreach ($sql as $query) {
            if (Db::getInstance()->execute($query) === false) {
                $sql_ok = false;
            }
        }
        return true;
    }

    public function uninstall()
    {
        // Deletes module tables
        Db::getInstance()->execute("DROP TABLE `'._DB_PREFIX_.'mfpswitchinvoicebill`;");
        return parent::uninstall();
    }

    public function hookDisplayBeforePayment($params)
    {
        $default_value = (int)Configuration::get('INVOICE_SWITCH_DEFAULT');
        $this->context->smarty->assign(array(
            'invoice_switch_default' => $default_value,
            'invoice_switch_url' => $this->context->link->getModuleLink($this->name, 'ajax', array(), true)
        ));
        return $this->display(__FILE__, 'views/templates/hook/invoice_switch.tpl');
    }


    public function hookActionOrderStatusUpdate($params)
    {
        if (isset($params['newOrderStatus']) && $params['newOrderStatus']->id == Configuration::get('PS_OS_PAYMENT')) {
            $invoice_switch = Tools::getValue('invoice_switch', null);
            var_dump($invoice_switch);
            if ($invoice_switch !== null) {
                $order_id = (int)$params['id_order'];
                $order = new Order($order_id);
                $order->invoice_switch = $invoice_switch;
                $order->update();
            }
        }
    }

}