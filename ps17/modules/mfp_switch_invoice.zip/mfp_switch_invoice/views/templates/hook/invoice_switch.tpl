<div class="form-group">
    <label for="invoice_switch">{l s='Faktura/Rachunek'}</label>
    <div class="checkbox">
        <label>
            <input type="checkbox" name="invoice_switch" id="invoice_switch" value="1" {if $invoice_switch_default}checked{/if}>
            {l s='Wybierz, czy chcesz otrzymać fakturę czy rachunek.'}
        </label>
    </div>
    <script type="text/javascript">
        {*$(document).ready(function() {*}
        {*    $('#invoice_switch').change(function() {*}
        {*        $.ajax({*}
        {*            type: 'POST',*}
        {*            url: '{$invoice_switch_url}',*}
        {*            data: 'ajax=true&invoice_switch=' + (this.checked ? '1' : '0'),*}
        {*            success: function() {*}
        {*                console.log('Invoice switch saved');*}
        {*            }*}
        {*        });*}
        {*    });*}
        {*});*}
    </script>
</div>