<?php
/**
 * LICENCE
 *
 * ALL RIGHTS RESERVED.
 * YOU ARE NOT ALLOWED TO COPY/EDIT/SHARE/WHATEVER.
 *
 * IN CASE OF ANY PROBLEM CONTACT AUTHOR.
 *
 *  @author    Jakub Przepióra (kontakt@nice-code.eu)
 *  @copyright nice-code.pl
 *  @license   ALL RIGHTS RESERVED
 */

class AttachmentsDocsOrderFiles extends ObjectModel
{
    const TABLE_NAME = 'mfp_attachments_docs_order_files';

    /** @var int id row */
    public $id_doc;

    /** @var string filename_txt */
    public $filename_txt;

    /** @var int active status */
    public $active;

    /** @see ObjectModel::$definition */
    public static $definition = array(
        'table' => self::TABLE_NAME,
        'primary' => 'id_doc',
        'fields' => array(
            'id_doc' => array('type' => self::TYPE_INT),
            'filename_txt' => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true),
            'active' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => true),
        )
    );
}