<?php
/**
 * LICENCE
 *
 * ALL RIGHTS RESERVED.
 * YOU ARE NOT ALLOWED TO COPY/EDIT/SHARE/WHATEVER.
 *
 * IN CASE OF ANY PROBLEM CONTACT AUTHOR.
 *
 *  @author    Jakub Przepióra (kontakt@nice-code.eu)
 *  @copyright nice-code.pl
 *  @license   ALL RIGHTS RESERVED
 */
require_once __DIR__.'/../mfp_attachments_docs_order.php';

class ManageSqlAttachments_docs_order {

    public $sqlQueries = [];
    public $prefix_table = 'mfp_attachments_docs_order_';
    public array $DB_tables = ["mfp_attachments_docs_order_files"];

    public function installQuaries()
    {
        $this->sqlQueries[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.$this->prefix_table.'files` (
				  `id_doc` int(11) NOT NULL AUTO_INCREMENT,
				  `filename_txt` VARCHAR(255) NOT NULL,
				  `active` INT(1) NOT NULL,
				  PRIMARY KEY (`id`)
				) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;';



        foreach ($this->sqlQueries as $query) {
            if (Db::getInstance()->execute($query) === false) {
                return false;
            }
        }
        return true;
    }

    public function uninstallQueries()
    {


        foreach ($this->DB_tables as $table) {
            if (Db::getInstance()->execute("DROP TABLE IF EXISTS `".$table."`;") === false) {
                return false;
            }
        }
        return true;
    }
}