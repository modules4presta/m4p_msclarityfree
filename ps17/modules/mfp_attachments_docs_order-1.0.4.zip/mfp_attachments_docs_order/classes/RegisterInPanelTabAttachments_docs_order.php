<?php
/**
 * LICENCE
 *
 * ALL RIGHTS RESERVED.
 * YOU ARE NOT ALLOWED TO COPY/EDIT/SHARE/WHATEVER.
 *
 * IN CASE OF ANY PROBLEM CONTACT AUTHOR.
 *
 *  @author    Jakub Przepióra (kontakt@nice-code.eu)
 *  @copyright nice-code.pl
 *  @license   ALL RIGHTS RESERVED
 */
class CustomMenuTabAttachmentsDocsOrder extends mfp_attachments_docs_order
{
    private $nameTab;
    private $class_name;
    private $position;

    public function __construct($nameTab, $class_name, $position)
    {
        $this->nameTab = $nameTab;
        $this->class_name = $class_name;
        $this->position = $position;
    }

    public function addTab()
    {
        $tab = new Tab();
        $tab->name = array();
        foreach(Language::getLanguages() as $lang) {
            $tab->name[$lang['id_lang']] = $this->nameTab;
        }

        $tab->class_name = $this->class_name;
        $tab->module = $this->class_name;
        $tab->id_parent = Tab::getIdFromClassName('AdminParentModules');
        $tab->active = true;
        $tab->save();

    }
    public function addSubTab($nameTab, $class_name, $position)
    {

        $id_parent = Tab::getIdFromClassName($this->class_name);

        if(!$id_parent) {
            throw new Exception('Nie znaleziono zakładki głównej.');
        }

        $sub_tab = new Tab();
        $sub_tab->name = array();
        foreach(Language::getLanguages() as $lang) {
            $sub_tab->name[$lang['id_lang']] = $nameTab;
        }

        $sub_tab->class_name = $class_name;
        $sub_tab->module = $this->class_name;
        $sub_tab->id_parent = $id_parent;

        $sub_tab->active = true;
        $sub_tab->save();

    }
}