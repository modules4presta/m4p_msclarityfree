<div class="panel">
    <div class="panel-heading">
        {l s='Ustawienia' mod='mfp_artbhp_importer'}
    </div>
    <div class="panel-body">
        <div class="container">
            <form id="configuration_form" class="defaultForm form-horizontal" method="post"
                enctype="multipart/form-data" novalidate="">
                <input type="hidden" name="submitAddconfiguration" value="1">
                <div class="form-wrapper">

                    <div class="col-12 col-lg-12">
                        <h3>Gdy produktu nie ma w CSV</h3>
                    </div>
                    <div class="form-group" style="display:flex;align-items:baseline;">

                        <div class="col-12 col-lg-12">
                            <div>
                                <div>
                                    <input type="radio" name="option_if_not_exist" id="option_if_not_exist_2" value="0"
                                        {if $integration_config.option == 0}checked{/if}>
                                    <label for="option_if_not_exist">Brak</label>
                                </div>
                                <div>
                                    <input type="radio" name="option_if_not_exist" id="option_if_not_exist_2" value="1"
                                        {if $integration_config.option == 1}checked{/if}>
                                    <label for="option_if_not_exist">Wyłącz produkt</label>
                                </div>
                                <div>
                                    <input type="radio" name="option_if_not_exist" id="option_if_not_exist_3" value="2"
                                        {if $integration_config.option == 2}checked{/if}>
                                    <label for="option_if_not_exist">Usuń produkt</label>
                                </div>
                            </div>
                            <p class="help-block">Akcja dla produktu, którego nie ma w pliku CSV ale jest w katalogu</p>
                        </div>

                    </div>

                    <div class="form-group">
                        <input type="text" id="addcoast" name="addcoast" placeholder="Marża procentowa" class="form-control">
                        <p class="help-block">Wpisując o ile procent ma się zwiększyć cena podczas importu produktów</p>

                    </div>
                    <div class="">
                        <h3>Dane do synchronizacji z serwerem FTP</h3>
                    </div>
                    <div class="form-group col-lg-12">

                        <label for="host_ftp">Host FTP do ArtBHP</label>
                        <input type="text" id="host_ftp" name="host_ftp" placeholder="HOST" class="form-control" value="{$integration_config.host_ftp}">

                        <label for="user_ftp">User FTP do ArtBHP</label>
                        <input type="text" id="user_ftp" name="user_ftp" placeholder="User" class="form-control" value="{$integration_config.user_ftp}">
                        <label for="password_ftp">Host FTP do ArtBHP</label>
                        <input type="password" id="password_ftp" name="password_ftp" placeholder="Password" class="form-control" value="{$integration_config.password_ftp}">

                    </div>
                    <div class="form-group col-lg-12">
                        <p>Kod cron</p>
                        <div class="card">
                            <code>
                                0 */12 * * * php {$integration_config.full_path}/modules/mfp_artbhp_importer/cron.php
                            </code>
                        </div>
                    </div>
                </div>

                <div class="panel-footer col-12 col-lg-12">
                    <button type="submit" value="1" id="configuration_form_submit_btn" name="saveconfig"
                        class="btn btn-default pull-right">
                        <i class="process-icon-save"></i> Zapisz
                    </button>
                </div>
        </div>
        </form>
    </div>
</div>