<?php

class mfp_artbhp_importerCronModuleFrontController extends ModuleFrontController
{
    /** @var bool If set to true, will be redirected to authentication page */
    public $auth = false;

    /** @var bool */
    public $ajax;

    public function display()
    {
        $this->ajax = 1;

        if (php_sapi_name() !== 'cli') {
            $this->ajaxRender('Forbidden call.');
        }

        $path = $this->download_latest_file_from_ftp(Configuration::get('host_ftp'),Configuration::get('user_ftp'),Configuration::get('password_ftp'),"/");

        $this->ajaxRender($path);
//        $this->ajaxRender("hello\n");
    }

    function download_latest_file_from_ftp($ftp_server, $ftp_username, $ftp_password, $remote_dir) {
        $conn_id = ftp_ssl_connect($ftp_server);
        $login_result = ftp_login($conn_id, $ftp_username, $ftp_password);

        if (!$conn_id || !$login_result) {
            return false;
        }

        ftp_pasv($conn_id, true);

        $files = ftp_nlist($conn_id, $remote_dir);
        $latest_file = '';
        $latest_timestamp = 0;

        foreach ($files as $file) {
            $timestamp = ftp_mdtm($conn_id, $file);

            if ($timestamp > $latest_timestamp) {
                $latest_file = $file;
                $latest_timestamp = $timestamp;
            }
        }

        if (empty($latest_file)) {
            return false;
        }

        $local_file = basename($latest_file);
        $local_path = _PS_MODULE_DIR_.'mfp_artbhp_importer/downloads/' . $local_file;

//        if (ftp_get($conn_id, $local_path, $latest_file, FTP_BINARY)) {
//            ftp_close($conn_id);
//            return $local_path;
//        } else {
//            ftp_close($conn_id);
//            return false;
//        }
        // Read CSV file
        $rows = [];
        // $rows = json_decode(Tools::getValue('rows'));

        try {
            $f_pointer = fopen(_PS_MODULE_DIR_.'mfp_artbhp_importer/downloads/'.$local_file, "r"); // file pointer

            // Get all rows from file
            while (!feof($f_pointer)) {
                array_push($rows, fgetcsv($f_pointer,null,"|"));
            }
        } catch (Exception $e) {
            throw new Exception('Błąd: ' . $e->getMessage());
        }

        // Check column names

        $columns = $rows[0];

        foreach ($columns as $key => $value) {
            $columns[$key] = strtoupper($value);
        }

        // Array to store row number for certain group name
        $group_row = [];


        // TODO: Add empty
        // column name error
        // TODO: Add scalable feature to add gruops. Iterate throught all columns and save those that exist in pr_group_lang.

        $posibleHeaders = ["PRODUCTID",
            "NAZWA",
            "SYMBOL",
            "ARTYKUL",
            "OPIS",
            "KOLOR",
            "WAGA",
            "EAN",
            "CENANET",
            "CENAGROS",
            "MALE",
            "DUZE",
            "MARKA",
            "DOSTEPNOSC",
            "DOST_STATUS",
            "DATA_DOST",
            "GRUPA",
            "ROZMIAR",
            "TABELA_ROZMIAROW",
            "VAT",
            "PRICENET",
            "PRICEGROSS",
            "CENANET_A",
            "KATEGORIA1",
            "KATEGORIA2",
            "KATEGORIA3",
            "KATEGORIA4"
        ];
        foreach ($posibleHeaders as $posibleHeader)
            if(array_search($posibleHeader, array_column($columns, 'destination'))) {
                array_push($errors, 'Nieznaleziono '.$posibleHeader);

            }


        if ($errors) {
            $this->displayErrors($errors);
            return;
        }
        foreach ($posibleHeaders as $posibleHeader)
            !empty($columns[0]) && $columns[0] != $posibleHeader ? array_push($errors, 'Nieprawidłowa nazwa kolumny: ' . $columns[0]) : '';

        $errors = null;
        if ($errors) {
            $this->displayErrors($errors);
            return;
        }

        $rows = array_splice($rows, 1, -1);

        // @TODO dorób ustawianie indeksu a asocjacji jako nazwy


        // Update PS product catalogue
//                    $processes = [];

        $processes = array();
        foreach ($rows as $row) {

            $pid = pcntl_fork();
            if ($pid == -1) {
                die('Nie udało się utworzyć procesu potomnego.');
            } elseif ($pid == 0) {

                $this->addRowByProduct($row);
                exit(0);
            } else {
                // Zapisujemy ID procesu potomnego
                $processes[] = $pid;
            }
        }


        foreach ($processes as $pid) {
            pcntl_waitpid($pid, $status);
        }

    }



}