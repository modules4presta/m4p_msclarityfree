<?php


class mfp_switch_invoiceajaxModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {

        if (Tools::getValue('action') == "setinvoice") {

            if(Tools::getValue("invoice_type") == 1 || Tools::getValue("invoice_type") == 0){
                Context::getContext()->cookie->invoice = Tools::getValue("invoice_type");
                Context::getContext()->invoiceBill = Tools::getValue("invoice_switch");
                echo "set invoiceOrBiil ".Tools::getValue("invoice_type");
            }
            else
                echo "Error";


            die;
        }
    }


}

