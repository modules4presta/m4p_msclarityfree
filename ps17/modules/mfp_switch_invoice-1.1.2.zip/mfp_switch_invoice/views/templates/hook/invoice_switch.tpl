<style>
    .switch-mfp {
        position: relative;
        display: inline-block;
        width: 30px;
        height: 21px;
    }

    .switch-mfp input#invoice-switch {
        opacity: 0;
        width: 0;
        height: 0;
    }

    .slider-mfp {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        -webkit-transition: .4s;
        transition: .4s;
    }

    .slider-mfp:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        -webkit-transition: .4s;
        transition: .4s;
    }

    input#invoice-switch:checked + .slider-mfp {
        background-color: #2196F3;
    }

    input#invoice-switch:focus + .slider-mfp {
        box-shadow: 0 0 1px #2196F3;
    }

    input#invoice-switch#invoice-switch:checked + .slider-mfp:before {
        -webkit-transform: translateX(13px);
        -ms-transform: translateX(13px);
        transform: translateX(13px);
    }

    /* Rounded sliders */
    .slider-mfp.round {
        border-radius: 34px;
    }

    .slider-mfp.round:before {
        border-radius: 50%;
    }
</style>
<div class="form-group">
    <label for="invoice-switch"><b>{l s='Rodzaj dokumentu'}</b></label>
    <div class="invoice-switch">
        <label>
            <input type="radio" name="invoice-type" value="0" {if $ifcheck == 0}checked{/if}>
            <span>{l s='Paragon'}</span>
        </label>
        <label>
            <input type="radio" name="invoice-type" value="1" {if $ifcheck == 1}checked{/if}>
            <span>{l s='Faktura'}</span>
        </label>
    </div>
</div>
<script>

</script>