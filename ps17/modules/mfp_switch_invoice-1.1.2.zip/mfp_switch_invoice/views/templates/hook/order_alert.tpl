<div class="alert alert-success d-print-none" id="mfp_invoice_alert" role="alert">
    <div class="alert-text text-center">
        <p>Klient chce {if $invoicebill == 1} Fakturę {else} Paragon {/if}</p>
    </div>
</div>

<script>
    window.onload = function() {
        const elementDoSkopiowania = document.querySelector('#mfp_invoice_alert');
        const elementDocelowy = document.querySelector('#customerCard .card-header');

        const sklonowanyElement = elementDoSkopiowania.cloneNode(true);
        elementDocelowy.appendChild(sklonowanyElement);
        elementDoSkopiowania.parentNode.removeChild(elementDoSkopiowania);
    }
</script>