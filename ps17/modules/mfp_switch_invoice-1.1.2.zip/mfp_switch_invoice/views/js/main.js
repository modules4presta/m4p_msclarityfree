$(document).ready(function() {
    $('input[name=invoice-type]').on('change', function() {

        $.ajax({
            url: ajax_get_map,
            type: "POST",
            data: {
                ajax: true,
                invoice_type: $(this).val()
            },
            success: function(data) {
                console.log('Invoice type updated');
                document.cookie = "invoice=" + $(this).val() + "; path=/";

            },
            error: function(xhr, ajaxOptions, thrownError) {
                console.log('Failed to update invoice type');
            }
        });
    });
});