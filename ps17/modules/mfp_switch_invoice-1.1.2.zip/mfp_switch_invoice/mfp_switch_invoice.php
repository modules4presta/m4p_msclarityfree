<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class mfp_switch_invoice extends Module
{
    public function __construct()
    {
        $this->name = 'mfp_switch_invoice';
        $this->tab = 'front_office_features';
        $this->version = '1.1.2';
        $this->author = 'Nice Code';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.6',
            'max' => '8.1.99',
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Switch Invoice/bill');
        $this->description = $this->l('Switch Invoice/bill in checkout');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        if (!Configuration::get('SELECT ADD')) {
            $this->warning = $this->l('No name provided');
        }
    }


    public function install()
    {

        if (!parent::install() ||
            !$this->registerHook('displayBeforePayment') ||
            !$this->registerHook('actionOrderStatusUpdate') ||
            !$this->registerHook('displayPaymentTop') ||
            !$this->registerHook('displayHeader') ||
            !$this->registerHook('displayBackOfficeFooter')
        ) {
            return false;
        }
        $sql_ok = true;
        $sql = array();
        $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'mfpswitchinvoicebill` (
				  `id` int(11) NOT NULL AUTO_INCREMENT,				  
				  `id_order` int(11) NOT NULL,
				  `invocie_bill` int(1) NOT NULL,			  
				  PRIMARY KEY (`id`)
				) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;';

        foreach ($sql as $query) {
            if (Db::getInstance()->execute($query) === false) {
                $sql_ok = false;
            }
        }
        return true;
    }

    public function uninstall()
    {
        // Deletes module tables
        Db::getInstance()->execute("DROP TABLE `'._DB_PREFIX_.'mfpswitchinvoicebill`;");
        return parent::uninstall();
    }

    public function hookDisplayBeforePayment($params)
    {
        $default_value = (int)Configuration::get('INVOICE_SWITCH_DEFAULT');
        $this->context->smarty->assign(array(
            'invoice_switch_default' => $default_value,
            'invoice_switch_url' => $this->context->link->getModuleLink($this->name, 'ajax', array(), true),

        ));

        return $this->display(__FILE__, 'views/templates/hook/invoice_switch.tpl');
    }




    public function hookActionOrderStatusUpdate($params)
    {
        $order_id = $params['id_order'];
        $invoice = Context::getContext()->cookie->invoice;
        $this->registerHook('displayBackOfficeFooter');

        Db::getInstance()->execute('INSERT INTO `'._DB_PREFIX_.'mfpswitchinvoicebill` (`id_order`, `invocie_bill`) VALUES ("' . $order_id . '","' . $invoice . '" );');

    }
    public function hookDisplayPaymentTop($params)
    {
        $link = new Link;
        $parameters_map = array("action" => "setinvoice");
        $ajax_get_map = $link->getModuleLink('mfp_switch_invoice', 'ajax', $parameters_map);
        $smarty = $this->context->smarty;

        $invoice_switch_default = $this->context->cookie->invoice_switch;
        $smarty->assign([
            'invoice_switch_default' => $invoice_switch_default,
            'ajax_get_map' => $ajax_get_map,
            'ifcheck' => (Context::getContext()->cookie->invoice) ? Context::getContext()->cookie->invoice : 0
        ]);

        return $this->display(__FILE__, 'views/templates/hook/invoice_switch.tpl');
    }

    public function hookDisplayHeader()
    {
        $link = new Link;
        $parameters_map = array("action" => "setinvoice");
        $ajax_get_map = $link->getModuleLink('mfp_switch_invoice', 'ajax', $parameters_map);
        Media::addJsDef(array(
            'ajax_get_map' => $ajax_get_map
        ));
        $this->context->controller->addJS($this->_path . 'views/js/main.js');
    }
    public function hookDisplayBackOfficeFooter($params){
        $order_id = (int)Tools::getValue('id_order');
        if(!$order_id) return;

        $invoiceBill = Db::getInstance()->getValue('SELECT invocie_bill FROM `'._DB_PREFIX_.'mfpswitchinvoicebill` WHERE id_order='.$order_id);
        $smarty = $this->context->smarty;
        $smarty->assign([

            'invoicebill' => $invoiceBill
        ]);
        return $this->display(__FILE__, 'views/templates/hook/order_alert.tpl');
    }
}