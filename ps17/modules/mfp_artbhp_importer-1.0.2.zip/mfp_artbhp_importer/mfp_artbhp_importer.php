<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class Mfp_artbhp_importer extends Module
{
    public function __construct()
    {
        $this->name = 'mfp_artbhp_importer';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Nice Code';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.6',
            'max' => '8.1.99',
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('ARTBHP integrator');
        $this->description = $this->l('Imports CSV file and creates/updates products');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        if (!Configuration::get('SELECT ADD')) {
            $this->warning = $this->l('No name provided');
        }
    }
    private function installSubTabs()
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = 'AdminIntegrationConfig';
        $tab->name = array();
        foreach (Language::getLanguages() as $lang) {
            $tab->name[$lang['id_lang']] = $this->trans('Konfiguracja synchronizacji', array(), 'Modules.ProductPersonalization.Admin', $lang['locale']);
        }
        $tab->id_parent = (int) Tab::getIdFromClassName('Mfp_artbhp_importer');
        $tab->module = $this->name;

        $tab->save();

        $tab1 = new Tab();
        $tab1->active = 1;
        $tab1->class_name = 'AdminImportCsvArtBhp';
        $tab1->name = array();
        foreach (Language::getLanguages() as $lang) {
            $tab1->name[$lang['id_lang']] = $this->trans('Single CSV Importer', array(), 'Modules.ProductPersonalization.Admin', $lang['locale']);
        }
        $tab1->id_parent = (int) Tab::getIdFromClassName('Mfp_artbhp_importer');
        $tab1->module = $this->name;

        $tab1->save();

        return true;
    }


    private function installTab()
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = 'Mfp_artbhp_importer';
        $tab->name = array();
        $tab->icon = 'sync';
        foreach (Language::getLanguages() as $lang) {
            $tab->name[$lang['id_lang']] = $this->trans('Single CSV Importer', array(), 'Modules.MyModule.Admin', $lang['locale']);
        }
        $tab->id_parent = (int) Tab::getIdFromClassName('DEFAULT');
        $tab->module = $this->name;

        $tab->save();
        $this->installSubTabs();
        return true;
    }
    public function install()
    {

        Configuration::updateValue('MFP_IMPORTER_CREATE_PROD', '1');
        Configuration::updateValue('MFP_IMPORTER_OPTION_PROD', '0');
        Configuration::updateValue('MFP_IMPORTER_DELETE_S_PRICE', '0');

        return parent::install() &&
            $this->registerHook('actionAdminControllerSetMedia') &&
            $this->installTab();
    }

    public function uninstall()
    {
        // Deletes module tables

        return parent::uninstall();
    }

    public function hookActionAdminControllerSetMedia()
    {
        $this->context->controller->addJS($this->_path . 'views/js/main.js');
    }

}