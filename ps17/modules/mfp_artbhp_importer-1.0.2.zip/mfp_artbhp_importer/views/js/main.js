window.onload = (event) => {


    document.getElementById("import_form_map_submit_btn").addEventListener("click", function(){

        let selectedMap = document.getElementById("map_selector").value;
        $.ajax({
            type: 'POST',
            url: ajax_get_map,
            data: "token="+token_admin+"&id_map="+selectedMap,
            success: function(data)
            {
                let map = JSON.parse(JSON.parse(data));

                //1-field-map
                const colCount = parseInt(document.getElementById('columns-count').value);
                console.log(map);
                map.forEach(obj => {
                    console.log(obj.destination, obj.target);

                    document.getElementById(obj.target+'-field-map').value = obj.destination;
                });

            }
        });
    });


};