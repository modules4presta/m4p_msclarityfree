{if isset($errors)}
    <div class="alert alert-danger">
        {foreach from=$errors item=error}
            <div>{$error}</div>
        {/foreach}
    </div>
{/if}
{if isset($success)}
    <div class="alert alert-success">
        {$success}
    </div>
    {if $import_errors}
        <div class="alert alert-warning">
            {foreach from=$import_errors item=import_error}
                <div>{$import_error}</div>
            {/foreach}
        </div>
    {/if}
{/if}
<div class="panel">
    <div class="panel-heading">
        {l s='Importuj' mod='mfp_artbhp_importer'}
    </div>
    <div class="panel-body">
        <div class="container">
            {if !isset($columns) && !isset($success)}
            <form id="import_form" class="defaultForm form-horizontal" method="post" enctype="multipart/form-data"
                novalidate="">
                <div class="form-wrapper">
                    <div class="form-group" style="display: flex; align-items: baseline;">
                        <label class="control-label col-lg-4">
                            Prześlij plik CSV:
                        </label>
                        <div class="col-lg-8">
                            <input type="file" name="csv_import_file" id="csv_import_file">
                            <p class="help-block">Prześlij z dysku plik CSV z danymi.</p>

                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="submit" value="1" id="import_form_submit_btn" name="confirmimport"
                            class="btn btn-default pull-right">
                            <i class="process-icon-save"></i> Importuj
                        </button>
                    </div>
                </div>
            </form>
               
            {else}
                {if isset($maps)}
                    <div class="panel">
                        <div class="panel-header">
                            <div class="title-row">
                                <h3 class="title">Wybierz mapowanie</h3>
                            </div>
                        </div>

                        <div class="panel-body">
                            <select class="form-control" id="map_selector">
                                {foreach $maps as $map}
                                    <option value="{$map["id"]}">{$map["title"]}</option>
                                {/foreach}
                            </select>
                            <br>
                            <button id="import_form_map_submit_btn"
                                class="btn btn-default pull-right">
                                Użyj mapowania
                            </button>
                        </div>
                    </div>
                {/if}
            <div class="clearfix"> </div>
            <div class="panel">
                <form id="import_with_map" class="defaultForm form-horizontal" method="post">
                    <div class="panel-header">
                        <h3 class="title">Ustaw nowe mapowanie</h3>
                    </div>
                    <div class="panel-body">
                        <table class="grid-table js-grid-table table  ">
                            <thead>
                                <tr>
                                    <td>ID</td>
                                    <td>Pola z pliku</td>
                                    <td>Pole przypisane</td>

                                </tr>
                            </thead>
                            <tbody>
                                {foreach $columns as $index => $col}
                                    <tr>

                                        <td>{$index+1}</td>
                                        <td>{$col}</td>
                                        <td>
                                            <select class="" id="{$index}-field-map" name="{$index}-field-map">
                                                <option value="pomin" selected>Pomiń kolumnę</option>
                                                <option value="sku">SKU</option>
                                                <option value="nazwa">NAZWA</option>
                                                <option value="cena">CENA</option>
                                                <option value="ilosc">ILOŚĆ</option>
                                                {if isset($groups)}
                                                    {foreach $groups as $group}
                                                        <option value="{$group["id_group"]}">{$group["name"]}</option>
                                                    {/foreach}
                                                {/if}
                                            </select>
                                        </td>

                                    </tr>
                                {/foreach}
                            </tbody>
                        </table>
                    </div>
                
                    <div class="panel-footer">
                        <div>
                            <input type="text" id="map_name" name="map_name" placeholder="Wpisz nazwe mapowania" class="form-control">
                        </div>
                        {if isset($columns)}
                        <input type="hidden" value="{$columns|count}" name="columns-count" id="columns-count">
                        {/if}
                        {if isset($file)}
                            <input type="hidden" value="{$file}" name="filename_to_import">
                        {/if}
                        <br>
                        <button type="submit" value="1" id="import_form_submit_btn" name="confirmimport_map"
                            class="btn btn-default pull-right">
                            <i class="process-icon-save"></i> Importuj
                        </button>
                    </div>
                </form>
            </div>
            {/if}
        </div>
    </div>
</div>