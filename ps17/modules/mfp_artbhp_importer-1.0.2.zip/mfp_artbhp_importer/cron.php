<?php

    $_GET['fc'] = 'module';
    $_GET['module'] = 'mfp_artbhp_importer';
    $_GET['controller'] = 'cron';
//echo  dirname(__FILE__);
    require_once dirname(__FILE__) . '/../../index.php';
