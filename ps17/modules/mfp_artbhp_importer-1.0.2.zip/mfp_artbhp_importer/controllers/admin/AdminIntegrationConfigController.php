<?php


class AdminIntegrationConfigController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initContent()
    {

        //Assign tpl vars
        $this->context->smarty->assign(
            [
                'integration_config' => [
                    'create' => Configuration::get('MFP_CREATE_PROD'),
                    'addcoast' => Configuration::get('MFP_ADDCOAST'),
                    'option' => Configuration::get('MFP_IMPORTER_OPTION_PROD'),
                    'delete_price' => Configuration::get('MFP_IMPORTER_DELETE_S_PRICE'),
                    'host_ftp' => Configuration::get('host_ftp'),
                    'user_ftp' => Configuration::get('user_ftp'),
                    'password_ftp' => Configuration::get('password_ftp'),
                    'full_path' => $_SERVER['DOCUMENT_ROOT']
                ]
            ]
        );

        // Render config view
        $this->content = $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'mfp_artbhp_importer/views/templates/admin/configure.tpl');

        return parent::initContent();
    }

    public function postProcess()
    {

        if (Tools::getIsset('saveconfig')) {

            //Save configuration
            Configuration::updateValue('MFP_CREATE_PROD', Tools::getValue('create_if_not_exist'));

            Configuration::updateValue('MFP_IMPORTER_OPTION_PROD', Tools::getValue('option_if_not_exist'));

            Configuration::updateValue('MFP_IMPORTER_DELETE_S_PRICE', Tools::getValue('delete_price_if_not_exist'));
            Configuration::updateValue('MFP_ADDCOAST', Tools::getValue('addcoast'));

            // FTP
            Configuration::updateValue('host_ftp', Tools::getValue('host_ftp'));
            Configuration::updateValue('user_ftp', Tools::getValue('user_ftp'));
            Configuration::updateValue('password_ftp', Tools::getValue('password_ftp'));

//            $this->addCronTask("0 6 * * *", "myCronFunction");
            $this->download_latest_file_from_ftp(Tools::getValue('host_ftp'), Tools::getValue('user_ftp'),Tools::getValue('password_ftp'), '/');
            //Refresh page to reset submit value
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminIntegrationConfig'));
        }

        parent::postProcess();
    }

    private function addCronTask($cronInterval, $cronFunction)
    {
        // Get the current list of cron tasks
        $existingCronTasks = Configuration::get('CRON_TASKS');

        // Parse the existing cron tasks as JSON
        $cronTasks = json_decode($existingCronTasks, true);

        // Check if the cron task already exists
        foreach ($cronTasks as $task) {
            if ($task['interval'] == $cronInterval && $task['function'] == $cronFunction) {
                // The task already exists, so we don't need to add it
                return;
            }
        }

        // Add the new cron task to the list
        $cronTasks[] = array(
            'interval' => $cronInterval,
            'function' => $cronFunction
        );

        // Encode the updated cron tasks as JSON
        $updatedCronTasks = json_encode($cronTasks);

        // Update the configuration value for the cron tasks
        Configuration::updateValue('CRON_TASKS', $updatedCronTasks);
    }
    static function download_latest_file_from_ftp($ftp_server, $ftp_username, $ftp_password, $remote_dir) {
        $conn_id = ftp_ssl_connect($ftp_server);
        $login_result = ftp_login($conn_id, $ftp_username, $ftp_password);

        if (!$conn_id || !$login_result) {
            return false;
        }

        ftp_pasv($conn_id, true);

        $files = ftp_nlist($conn_id, $remote_dir);
        $latest_file = '';
        $latest_timestamp = 0;

        foreach ($files as $file) {
            $timestamp = ftp_mdtm($conn_id, $file);

            if ($timestamp > $latest_timestamp) {
                $latest_file = $file;
                $latest_timestamp = $timestamp;
            }
        }

        if (empty($latest_file)) {
            return false;
        }

        $local_file = basename($latest_file);
        $local_path = _PS_MODULE_DIR_.'mfp_artbhp_importer/downloads/' . $local_file;

        if (ftp_get($conn_id, $local_path, $latest_file, FTP_BINARY)) {
            ftp_close($conn_id);
            return $local_path;
        } else {
            ftp_close($conn_id);
            return false;
        }
    }
}
