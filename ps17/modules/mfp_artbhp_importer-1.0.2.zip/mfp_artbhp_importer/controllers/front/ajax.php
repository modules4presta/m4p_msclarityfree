<?php



class mfp_artbhp_importerAjaxModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {


        if (Tools::getAdminToken('AdminModules') != Tools::getValue('token')) {
            // Ooops! Token is not valid!
            die('Token is not valid, hack stop');
            return;
        }


        if (Tools::getValue('action') == "addproduct") {
            $row = json_decode(file_get_contents('php://input'), true);
            if ($row[7] == "") return false;
            $product = $this->getProductByEan($row[7]);

            // Create product
            if (!$product) {

                $product = new Product();

                // set EAN

                $product->ean13 = $row[7];
                $product->reference = $row[7];
                $categoryForProduct = $this->createCategoryTree([$row[23], $row[24], $row[25], $row[26]]);

                $product->addToCategories($categoryForProduct);
                $brandId = $this->createBrand($row[12]);
                if ($brandId)
                    $product->id_manufacturer = $brandId;

                // price net
            }


            //Set product name
            if (!empty($row[1]))
                $product->name = $row[1];
            if (!empty($row[1]) && !empty($row[2]))
                $product->name = $row[1] . "-" . $row[2];


            //Set description
            if (!empty($row[4]))
                $product->description = $row[4];

            //  Set next supply
            if (!empty($row[4]) && !empty($row[15]))
                $product->description = $row[4] . "<br></b><b>Dostępne: </b>" . $row[15];

            // Set weight
            if (!empty($row[6]))
                $product->weight = $row[6];


            // Disable product if there is no price
            !empty($row[20]) ? $product->price = $row[20] : $product->active = false;

            // avabiliity
            ($row[13] == "TAK") ? $product->active = true : $product->active = false;

            $product->save();

            // Set image
            if (!empty($row[11])) {
                $this->addProductImage($product->id, $row[11]);
            }
            $json = json_encode(["status" => "added"]);
            echo $json;
            //        return $json;
            die;
        }







    }
    private function addProductImage($product_id, $image_url) {
        $product = new Product($product_id);
        if (!Validate::isLoadedObject($product)) {
            return false; // produkt nie istnieje, zwracamy wartość false
        }

        // Dodajemy zdjęcie do bazy danych
        $image = new Image();
        $image->id_product = $product_id;
        $image->position = Image::getHighestPosition($product_id) + 1; // Ustawiamy pozycję zdjęcia
        if (!$image->add()) {
            return false; // nie udało się dodać zdjęcia, zwracamy wartość false
        }

        // Pobieramy nazwę pliku z URL i zapisujemy zdjęcie w katalogu PrestaShop
        $filename = basename($image_url);
        $path = _PS_PROD_IMG_DIR_ . $filename;
        if (!file_put_contents($path, file_get_contents($image_url))) {
            $image->delete(); // usuwamy zdjęcie z bazy danych, jeśli nie udało się zapisać pliku
            return false;
        }

        // Przypisujemy zdjęcie do produktu
//        $this->addProductImage($image->id, false);

        return true; // zwracamy wartość true, jeśli udało się dodać zdjęcie do produktu
    }

}

