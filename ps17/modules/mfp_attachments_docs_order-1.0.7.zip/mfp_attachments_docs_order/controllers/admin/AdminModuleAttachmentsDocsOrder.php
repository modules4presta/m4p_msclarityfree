<?php
/**
 * LICENCE
 *
 * ALL RIGHTS RESERVED.
 * YOU ARE NOT ALLOWED TO COPY/EDIT/SHARE/WHATEVER.
 *
 * IN CASE OF ANY PROBLEM CONTACT AUTHOR.
 *
 *  @author    Jakub Przepióra (kontakt@nice-code.eu)
 *  @copyright nice-code.pl
 *  @license   ALL RIGHTS RESERVED
 */
require_once dirname(__FILE__) . '/../../classes/AttachmentsDocsOrderFiles.php';
class AdminModuleAttachmentsDocsOrderController extends ModuleAdminControllerCore
{



    /** @var int id row */
    public $id_doc;


    /** @var string filename_txt */
    public $filename_txt;

    /** @var int active status */
    public $active;

    const TABLE_NAME = 'mfp_attachments_docs_order_files';

    public function __construct()
    {
        $this->context = Context::getContext();
        $this->name = 'mfp_attachments_docs_order';
        $this->tab = 'administration';
        $this->table = 'mfp_attachments_docs_order_files';
        $this->identifier = 'id_doc';
        $this->className = 'AttachmentsDocsOrderFiles';
        $this->_defaultOrderBy = 'filename_txt';
        $this->lang = false;
        $this->bootstrap = true;
        $this->addRowAction('edit');
        $this->addRowAction('delete');


        $this->bulk_actions = array('delete' => array(
            'text' => 'Delete selected',
            'confirm' => 'Delete selected items?'
        ),);

        $this->_select = 'id_doc';
        $this->fields_list = array(
            'id_doc' => array('title' => 'ID', 'align' => 'center', 'width' => 20),
            'filename_txt' => array('title' => 'Nazwa pliku', 'align' => 'center', 'width' => 60),
            'id_order_state' => array('title' => 'Status', 'align' => 'center', 'width' => 60),
            'active' => array('title' => 'Aktywność', 'align' => 'center', 'width' => 20 ),

        );
        $this->toolbar_btn[] = array(
            'href' => $this->context->link->getAdminLink('mfp_attachments_docs_order'),
            'title' => 'Back',
            'imgclass' => 'back',
            'desc' => 'Back ',
        );
        parent::__construct();
    }


    public function getOrderState() {

        $states = Db::getInstance()->executeS("SELECT * FROM `". _DB_PREFIX_ . "order_state_lang`;");
        $result = [];
        foreach($states as $state) {
            $result[] = [
                "id_option" => $state["id_order_state"],
                "name" => $state["name"]
            ];
        }

        return $result;

    }
    public function renderForm()
    {
        $this->initToolbar();

        $this->fields_form  = array(
                'legend' => array(
                    'title' => $this->l('Dodawanie pliku'),
                ),
                'input' => array(
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Włącz/Wyłącz'),
                        'name' => 'active',
                        'required' => false,
                        'is_bool' => true,
                        'desc' => $this->l('Włącz lub wyłącz plik'),
                        'values' => array(
                            array(
                                'id' => 'enabled_on',
                                'value' => 1,
                                'label' => $this->l('Włącz'),
                            ),
                            array(
                                'id' => 'enabled_off',
                                'value' => 0,
                                'label' => $this->l('Wyłącz'),
                            ),
                        ),
                    ),
                    array(
                        'type' => 'file',
                        'label' => $this->l('Plik'),
                        'name' => 'filename_txt',
                        'required' => false,
                        'desc' => $this->l('Dodaj plik'),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Moduł'),
                        'name' => 'id_order_state',
                        'required' => true,
                        'size' => 10,
                        'setWidth'=> 300,
                        'options' => array(
                            'query' => $this->getOrderState(),
                            'id' => 'id_option',
                            'name' => 'name',
                        ),

                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Zapisz'),
                    'class' => 'btn btn-default button',
                ),
        );

        return parent::renderForm();

    }

    public function postProcess()
    {

        if (Tools::isSubmit('submitAddmfp_attachments_docs_order_files'))
        {
            // Odczytaj przesłany plik
            $file = $_FILES['filename_txt'];

            // Sprawdź, czy plik został przesłany poprawnie
            if ($file['error'] === UPLOAD_ERR_OK)
            {
                // Pobierz nazwę i ścieżkę tymczasowego pliku
                $filename = $file['name'];
                $tmpFilePath = $file['tmp_name'];

                // Przeniesienie pliku do docelowej lokalizacji
                $destinationPath = _PS_MODULE_DIR_.'mfp_attachments_docs_order/uploads/'. $filename;
                if (move_uploaded_file($tmpFilePath, $destinationPath))
                {

                    $this->confirmations[] = $this->l('Plik został pomyślnie przesłany i zapisany.');
                }
                else
                {
                    // Wystąpił błąd podczas zapisywania pliku
                    $this->errors[] = $this->l('Wystąpił błąd podczas zapisywania pliku.');
                }
            }
            else
            {
                // Wystąpił błąd podczas przesyłania pliku
                $this->errors[] = $this->l('Wystąpił błąd podczas przesyłania pliku.');
            }
        }

        return parent::postProcess();
    }

}