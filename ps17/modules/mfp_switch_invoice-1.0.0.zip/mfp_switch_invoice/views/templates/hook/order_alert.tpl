<div class="alert alert-success d-print-none" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true"><i class="material-icons">close</i></span>
    </button>
    <div class="alert-text text-center">
        <p>Klient chce {if $invoicebill == 1} Fakturę {else} Rachunek {/if}</p>
    </div>
</div>