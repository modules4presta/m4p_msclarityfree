$(document).ready(function() {
    $('#invoice-switch').on('change', function() {
        alert("s");
        $.ajax({
            url: ajax_get_map,
            type: "POST",
            data: {
                ajax: true,
                invoice_switch: $(this).is(':checked') ? 1 : 0
            },
            success: function(data) {
                console.log('Invoice switch updated');
                document.cookie = "invoice=1; path=/";

            },
            error: function(xhr, ajaxOptions, thrownError) {
                console.log('Failed to update invoice switch');
            }
        });
    });
});