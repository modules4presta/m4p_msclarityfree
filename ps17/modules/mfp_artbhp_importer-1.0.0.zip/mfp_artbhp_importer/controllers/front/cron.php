<?php

require_once __DIR__.'../../admin/AdminImportCsvArtBhpController.php';
//require_once __DIR__.'/classes/ManageSql.php';

class mfp_artbhp_importerCronModuleFrontController extends ModuleFrontController
{
    /** @var bool If set to true, will be redirected to authentication page */
    public $auth = false;

    /** @var bool */
    public $ajax;

    public function display()
    {

        // start cron method
        $this->ajax = 1;

        if (php_sapi_name() !== 'cli') {
            $this->ajaxRender('Forbidden call.');
        }

        $path = $this->download_latest_file_from_ftp(Configuration::get('host_ftp'),Configuration::get('user_ftp'),Configuration::get('password_ftp'),"/");

        $this->ajaxRender($path);

    }

    function download_latest_file_from_ftp($ftp_server, $ftp_username, $ftp_password, $remote_dir) {
        $conn_id = ftp_ssl_connect($ftp_server);
        $login_result = ftp_login($conn_id, $ftp_username, $ftp_password);

        if (!$conn_id || !$login_result) {
            return false;
        }

        ftp_pasv($conn_id, true);

        $files = ftp_nlist($conn_id, $remote_dir);
        $latest_file = '';
        $latest_timestamp = 0;

        foreach ($files as $file) {
            $timestamp = ftp_mdtm($conn_id, $file);

            if ($timestamp > $latest_timestamp) {
                $latest_file = $file;
                $latest_timestamp = $timestamp;
            }
        }

        if (empty($latest_file)) {
            return false;
        }

        $local_file = basename($latest_file);
        $local_path = _PS_MODULE_DIR_.'mfp_artbhp_importer/downloads/' . $local_file;
        $handle = fopen($local_path, 'w');
        if (ftp_fget($conn_id, $handle, $latest_file, FTP_BINARY)) {
            fclose($handle);
            echo "Downloaded file\n";
        } else {
            fclose($handle);
            return false;
        }

        // Read CSV file
        $rows = [];
        // $rows = json_decode(Tools::getValue('rows'));

        try {
            $f_pointer = fopen(_PS_MODULE_DIR_.'mfp_artbhp_importer/downloads/'.$local_file, "r"); // file pointer
            echo "Open file first\n";
            // Get all rows from file
            while (!feof($f_pointer)) {
                array_push($rows, fgetcsv($f_pointer,null,"|"));
            }
        } catch (Exception $e) {
            throw new Exception('Błąd: ' . $e->getMessage());
        }

        // Check column names

        $columns = $rows[0];

        foreach ($columns as $key => $value) {
            $columns[$key] = strtoupper($value);
        }

        $posibleHeaders = ["PRODUCTID",
            "NAZWA",
            "SYMBOL",
            "ARTYKUL",
            "OPIS",
            "KOLOR",
            "WAGA",
            "EAN",
            "CENANET",
            "CENAGROS",
            "MALE",
            "DUZE",
            "MARKA",
            "DOSTEPNOSC",
            "DOST_STATUS",
            "DATA_DOST",
            "GRUPA",
            "ROZMIAR",
            "TABELA_ROZMIAROW",
            "VAT",
            "PRICENET",
            "PRICEGROSS",
            "CENANET_A",
            "KATEGORIA1",
            "KATEGORIA2",
            "KATEGORIA3",
            "KATEGORIA4"
        ];
        $errors = [];
        foreach ($posibleHeaders as $posibleHeader)
            if (array_search($posibleHeader, array_column($columns, 'destination'))) {
                array_push($errors, 'Nieznaleziono ' . $posibleHeader);

            }


        if ($errors) {
            $this->displayErrors($errors);
            return;
        }
        foreach ($posibleHeaders as $posibleHeader)
            !empty($columns[0]) && $columns[0] != $posibleHeader ? array_push($errors, 'Nieprawidłowa nazwa kolumny: ' . $columns[0]) : '';

        $errors = null;
        if ($errors) {
            $this->displayErrors($errors);
            return;
        }

        // clean buffor
        $rows = [];

        $count_line = 0;
        try {
            $f_pointer = fopen(_PS_MODULE_DIR_.'mfp_artbhp_importer/downloads/'.$local_file, "r"); // file pointer
            echo "Open file second\n";
            // Get all rows from file
            while (!feof($f_pointer)) {
                $row = fgetcsv($f_pointer,null,"|");
                if($count_line == 0) {
                    $count_line++;

                    continue;
                }
                var_dump($row);
                echo "start data\n";

                ob_start();
                if (!isset($row[7]) || $row[7] == "") continue;
                $product = $this->getProductByEan($row[7]);
                // Create product
                if (!$product) {

                    $product = new Product();
                    echo $row[7];
                    // set EAN
                    if (strlen($row[7]) > 13) {
                        $product->ean13 = substr($row[7], 0, 13);
                    } else
                        $product->ean13 = $row[7];
                    $product->reference = $row[7];

                    // price net

//                            category

                }

                $categoryForProduct = $this->createCategoryTree([$row[23], $row[24], $row[25], $row[26]]);

                $resultAdd = $product->addToCategories($categoryForProduct);
                $resultUpdate = $product->updateCategories($categoryForProduct);
                $product->id_category_default = end($categoryForProduct);


                $brandId = $this->createBrand($row[12]);
                if ($brandId)
                    $product->id_manufacturer = $brandId;



                //Set product name
                if (!empty($row[1]))
                    $product->name = $row[1];
                if (!empty($row[1]) && !empty($row[2]))
                    $product->name = $row[1] . "-" . $row[2];


                //Set description
                if (!empty($row[4]))
                    $product->description = $row[4];

                //  Set next supply
                if (!empty($row[4]) && !empty($row[15]))
                    $product->description = $row[4] . "<br></b><b>Dostępne: </b>" . $row[15];
                elseif (!empty($row[14]))
                    $product->description = $row[4] ." ". $row[14];
                // Set weight
                var_dump($row[6]);
                if (!empty($row[6]) && !is_string($row[6]))
                    $product->weight = $row[6];


                // Disable product if there is no price nett
                $procent_benefits = Configuration::get('MFP_ADDCOAST');

                !empty($row[20]) ? $product->price = floatval($row[20]) : $product->active = false;

                if(floatval($procent_benefits) > 0)
                    $product->price = floatval($row[20]) *( 1 + (floatval($procent_benefits) / 100));
                // avabiliity
                ($row[13] == "TAK") ? $product->active = true : $product->active = false;
                $product->save();
                $product->id_tax_rules_group = 1;

                $product->update();
                // price brutto
//                        !empty($row[21]) ? $product-> = $row[21] : $product->active = false;

                // Set image
                if (!empty($row[11])) {
                    $this->addProductImage($product->id, $row[11]);
                }
                ob_end_clean();
                $product->save();


                $count_line++;
            }
        } catch (Exception $e) {
            throw new Exception('Błąd: ' . $e->getMessage());
        }





        return  $count_line;
    }

    private function addProductImage($product_id, $image_url) {

        // Sprawdź, czy istnieje już zdjęcie dla tego produktu
        $product_images = Image::getImages($this->context->language->id, $product_id);
        foreach ($product_images as $product_image) {
            if ($product_image['cover'] == 1) {
                // Zdjęcie już istnieje, nie dodawaj nowego zdjęcia
//                Image::deleteImages($product_id);
                Image::deleteCover($product_id);
                break;
            }
        }

        $image = new Image();
        $image->id_product = $product_id;
        $image->position = \Image::getHighestPosition($product_id) + 1;
        $image->cover = true;
        $image->add();
        if (! AdminImportCsvArtBhpController::copyImg($product_id, $image->id, $image_url, 'products', true)) {
            $image->delete();
        }
    }
    public static function copyImg($id_entity, $id_image, $url, $entity = 'products', $regenerate = true)
    {


        $tmpfile = tempnam(_PS_TMP_IMG_DIR_, 'ps_import');
        $watermark_types = explode(',', \Configuration::get('WATERMARK_TYPES'));

        switch ($entity) {
            default:
            case 'products':
                $image_obj = new \Image($id_image);
                $path = $image_obj->getPathForCreation();
                break;
            case 'categories':
                $path = _PS_CAT_IMG_DIR_ . (int)$id_entity;
                break;
            case 'manufacturers':
                $path = _PS_MANU_IMG_DIR_ . (int)$id_entity;
                break;
            case 'suppliers':
                $path = _PS_SUPP_IMG_DIR_ . (int)$id_entity;
                break;
            case 'stores':
                $path = _PS_STORE_IMG_DIR_ . (int)$id_entity;
                break;
        }

        //FIX FOR SSL ISSUE ON LOCAL
        stream_context_set_default(array(
            'ssl' => array(
                'peer_name' => 'generic-server',
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        ));
        $opts = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false
            )
        );

        $cos= stream_context_create($opts);
        $response = file_get_contents($url, false,$cos);

        if (file_put_contents($tmpfile, $response)) {
            if (!\ImageManager::checkImageMemoryLimit($tmpfile)) {
                @unlink($tmpfile);
                return false;
            }

            $tgt_width = $tgt_height = 0;
            $src_width = $src_height = 0;
            $error = 0;
//            \ImageManager::resize($tmpfile, $path . '.jpg', null, null, 'jpg', false, $error, $tgt_width, $tgt_height, 5, $src_width, $src_height);
            $images_types = \ImageType::getImagesTypes($entity, true);

            if ($regenerate) {
                $previous_path = null;
                $path_infos = array();
                $path_infos[] = array($tgt_width, $tgt_height, $path . '.jpg');
                foreach ($images_types as $image_type) {
                    $tmpfile = self::get_best_path($image_type['width'], $image_type['height'], $path_infos);

                    if (\ImageManager::resize(
                        $path . '.jpg',
                        $path . '-' . stripslashes($image_type['name']) . '.jpg',
                        $image_type['width'],
                        $image_type['height'],
                        'jpg',
                        false,
                        $error,
                        $tgt_width,
                        $tgt_height,
                        5,
                        $src_width,
                        $src_height
                    )) {

                        if ($tgt_width <= $src_width && $tgt_height <= $src_height) {
                            $path_infos[] = array($tgt_width, $tgt_height, $path . '-' . stripslashes($image_type['name']) . '.jpg');
                        }
                        if ($entity == 'products') {
                            if (is_file(_PS_TMP_IMG_DIR_ . 'product_mini_' . (int)$id_entity . '.jpg')) {
                                unlink(_PS_TMP_IMG_DIR_ . 'product_mini_' . (int)$id_entity . '.jpg');
                            }
                            if (is_file(_PS_TMP_IMG_DIR_ . 'product_mini_' . (int)$id_entity . '_' . (int)\Context::getContext()->shop->id . '.jpg')) {
                                unlink(_PS_TMP_IMG_DIR_ . 'product_mini_' . (int)$id_entity . '_' . (int)\Context::getContext()->shop->id . '.jpg');
                            }
                        }
                    }
                    \Hook::exec('actionWatermark', array('id_image' => $id_image, 'id_product' => $id_entity));
                }
            }
        } else {
            @unlink($tmpfile);
            return false;
        }
        return true;
    }
    public static function get_best_path($width, $height, $existing_images) {
        $best_path = null;
        $best_score = null;
        foreach ($existing_images as $image) {
            $image_width = $image[0];
            $image_height = $image[1];
            $image_path = $image[2];
            if ($width <= $image_width && $height <= $image_height) {
                $score = $image_width * $image_height - $width * $height;
                if ($best_score === null || $score < $best_score) {
                    $best_path = $image_path;
                    $best_score = $score;
                }
            }
        }
        return $best_path;
    }
    private function displayErrors($errors)
    {

//        $errors = (empty($errors))? $errors : null;
        $this->context->smarty->assign('errors', $errors);
        return $this->content = $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'mfp_artbhp_importer/views/templates/admin/import.tpl');
    }

    private function updateSpecificPrice($product, $id_group, $price)
    {
        if (!$id_specific_price = $this->getSpecificPriceIdByProductIdAndGroupId($product->id, $id_group)) {
            $specificPrice = new SpecificPrice();
            $specificPrice->id_product = $product->id;
            $specificPrice->id_shop = $this->context->shop->id;
            $specificPrice->id_currency = 0;
            $specificPrice->from_quantity = 1;
            $specificPrice->reduction = 0;
            $specificPrice->id_country = 0;
            $specificPrice->id_customer = 0;
            $specificPrice->from = '0000-00-00 00:00:00';
            $specificPrice->to = '0000-00-00 00:00:00';
            $specificPrice->reduction_type = 'amount';
            $specificPrice->reduction_tax = 1;
            $specificPrice->id_group = $id_group; // TODO: Might need to add better client group id assigment
        } else {
            $specificPrice = new SpecificPrice((int)$id_specific_price);
        }
        $specificPrice->price = str_replace(',', '.', $price);
        $specificPrice->save();
    }

    private function getSpecificPriceIdByProductIdAndGroupId($id_product, $id_group)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
                SELECT id_specific_price
                FROM `' . _DB_PREFIX_ . 'specific_price`
                WHERE `id_product` = ' . (int) $id_product . ' AND `id_group` = ' . $id_group);
    }

    private function deleteSpecificPrice($id_specific_price)
    {
        $sp = new SpecificPrice($id_specific_price);
        $sp->delete();
    }

    private function isSkuAvailable($reference)
    {
        $available = Db::getInstance()->getValue('SELECT `id_product` FROM ' . _DB_PREFIX_ . 'product WHERE `reference` = "' . $reference . '"');
        return !empty($available);
    }

    private function getPsProductIds()
    {
        $arr = Db::getInstance()->executeS('SELECT id_product FROM ' . _DB_PREFIX_ . 'product');
        $orr = [];
        foreach ($arr as $id) {
            array_push($orr, $id['id_product']);
        }
        return $orr;
    }

    private function disableDeletePsProducts($csv_ids, $option)
    {
        $ids_to_disable = array_diff($this->getPsProductIds(), $csv_ids);
        foreach ($ids_to_disable as $id) {
            $prod = new Product($id);
            if ($option == 1) {
                $prod->active = 0;
                $prod->save();
            } else {
                $prod->delete();
            }
        }
    }

    private function getPsGroups()
    {
        $raw = Db::getInstance()->executeS('SELECT `id_group`, `name` FROM ' . _DB_PREFIX_ . 'group_lang');
        $result = [];
        foreach ($raw as $arr) {
            $result[strtoupper($arr['name'])] = $arr['id_group'];
        }
        return $result;
    }
    public function createCategoryTree($cats) {

        $parent_id = 3;



        $category_ids = [];

        $allCategoriesExists = Category::getAllCategoriesName();

        for ($i = 0; $i < count($cats); $i++) {
            if($cats[$i] =="") continue;

            $name = $cats[$i];
            $findCat = Category::searchByName(Context::getContext()->language->id, $name);
            $indexExist = array_search($name, array_column($allCategoriesExists,"name"));


            if($indexExist != false) {
                $category_ids[] = $allCategoriesExists[$indexExist]["id_category"];

                continue;
            }

            if(!empty($findCat)) {
                $category_ids[] = $findCat[0]["id_category"];

                continue;
            }


            // CREATE NEW CATEGORY
            $new_category = new Category();
            $new_category->name = [(int)Configuration::get('PS_LANG_DEFAULT') => $name];

            $new_category->id_parent = $parent_id;
            $new_category->active = true;
            $new_category->position = 1;

            $new_category->link_rewrite = [(int)Configuration::get('PS_LANG_DEFAULT') => Tools::link_rewrite($name)];

            if($new_category->add()) {
                $addsCategory[] = $new_category->name;
            }


            $category_ids[] = $new_category->id;
            $parent_id = $new_category->id;
        }
        return $category_ids;
    }

    public function createBrand($manufacturerName) {
        if(empty($manufacturerName)) return false;
        $manufacturer = Manufacturer::getIdByName($manufacturerName);
        if ($manufacturer) {

            return $manufacturer;
        } else {

            $newManufacturer = new Manufacturer();
            $newManufacturer->name = $manufacturerName;
            $newManufacturer->active = true;
            $newManufacturer->add();
            return $newManufacturer->id;
        }
    }
    private function getPsGroupsDetail()
    {

        return Db::getInstance()->executeS('SELECT `id_group`, `name` FROM ' . _DB_PREFIX_ . 'group_lang');
    }

    private function getProductByEan($id_product)
    {
        $id = Db::getInstance()->getValue('SELECT `id_product` FROM ' . _DB_PREFIX_ . 'product WHERE `ean13` = "' . $id_product . '"');
        if ($id) {
            return new Product($id);
        }
        return false;
    }

}