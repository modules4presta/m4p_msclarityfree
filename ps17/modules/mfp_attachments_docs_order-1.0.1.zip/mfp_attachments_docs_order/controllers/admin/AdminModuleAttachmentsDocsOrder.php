<?php
/**
 * LICENCE
 *
 * ALL RIGHTS RESERVED.
 * YOU ARE NOT ALLOWED TO COPY/EDIT/SHARE/WHATEVER.
 *
 * IN CASE OF ANY PROBLEM CONTACT AUTHOR.
 *
 *  @author    Jakub Przepióra (kontakt@nice-code.eu)
 *  @copyright nice-code.pl
 *  @license   ALL RIGHTS RESERVED
 */
require_once dirname(__FILE__) . '/../../classes/AttachmentsDocsOrderFiles.php';
class AdminModuleAttachmentsDocsOrderController extends ModuleAdminControllerCore
{



    /** @var int id row */
    public $id;


    /** @var string filename */
    public $filename;

    /** @var int active status */
    public $active;



    const TABLE_NAME = 'mfp_attachments_docs_order';

    public function __construct()
    {

        $this->context = Context::getContext();
        $this->table = 'mfp_attachments_docs_order_files';
        $this->identifier = 'id';
        $this->className = 'AttachmentsDocsOrderFiles';
        $this->_defaultOrderBy = 'id';
        $this->lang = false;
        $this->bootstrap = true;
//        $this->explicitSelect = true;
        $this->addRowAction('edit');
        $this->addRowAction('delete');


        $this->bulk_actions = array('delete' => array(
            'text' => 'Delete selected',
            'confirm' => 'Delete selected items?'
        ),);

        $this->_select = 'id';
        $this->fields_list = array(
            'id' => array('title' => 'ID', 'align' => 'center', 'width' => 25),
            'filename' => array('title' => 'Nazwa pliku', 'align' => 'center', 'width' => 25),
            'active' => array('title' => 'Aktywność', 'align' => 'center', 'width' => 60 ),

        );

        $this->toolbar_btn[] = array(
            'href' => $this->context->link->getAdminLink('mfp_license_manager'),
            'title' => 'Back',
            'imgclass' => 'back',
            'desc' => 'Back ',
        );




        parent::__construct();
    }

    public function renderForm()
    {
        $this->initToolbar();

        $this->fields_form = array(
            'legend' => array(
                'title' => $this->l('Dodawanie pliku'),
            ),
            'input' => array(

                array(
                    'type' => 'switch',
                    'label' => $this->l('Włącz/Wyłącz'),
                    'name' => 'enabled',
                    'required' => false,
                    'is_bool' => true,
                    'desc' => $this->l('Włącz lub wyłącz plik'),
                    'values' => array(
                        array(
                            'id' => 'enabled_on',
                            'value' => 1,
                            'label' => $this->l('Włącz'),
                        ),
                        array(
                            'id' => 'enabled_off',
                            'value' => 0,
                            'label' => $this->l('Wyłącz'),
                        ),
                    ),
                ),
                array(
                    'type' => 'file',
                    'label' => $this->l('Plik'),
                    'name' => 'file_upload',
                    'required' => false,
                    'desc' => $this->l('Dodaj plik'),
                ),
            ),
            'submit' => array(
                'title' => $this->l('Zapisz'),
                'class' => 'btn btn-default button'
            ),
        );

        return parent::renderForm();
    }


}