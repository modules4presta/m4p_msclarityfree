{*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*}
{literal}
    <style>
        .add-product-to-free-delivery .product{
            margin-right: 5px !important;
        }
        #add-product-to-free-delivery {
            display: grid;
            gird-template-column: 30% 30% 30%;
        }
    </style>
    <script>

    </script>
{/literal}
<section id="list_product_addtofreedelivery">
    <input type="hidden" id="currently_cart_id" value="{$currently_cart_id}">
    {if !empty($freeShippingProducts) && isset($priceToFreeDelivery) && $priceToFreeDelivery}
        <div style="margin-bottom:5px;float:left;width:100%">{l s='For free delivery missing:' mod='addtofreedelivery'}
            <span style="font-size: 18px;font-weight: bold;"> {$priceToFreeDeliveryWithCurrency} </span>
            {l s='Choose products for your order to receive free delivery:' mod='addtofreedelivery'}
        </div>
    {/if}
    <div id="add-product-to-free-delivery" style="margin-bottom:5px;float:left; display:flex;gap:10px;">
        {if isset($freeShippingProducts) && $freeShippingProducts}
            {foreach from=$freeShippingProducts item="product"}
                {include file="catalog/_partials/miniatures/product.tpl" product=$product}
            {/foreach}
        {/if}
    </div>
</section>
