<?php

require_once __DIR__.'/classes/ModulesForPrestaMarketing.php';
require_once __DIR__.'/classes/ModulesForPrestaConnector.php';
require_once __DIR__.'/classes/ManageSql.php';


if (!defined('_PS_VERSION_')) {
    exit;
}

class mfp_topinfobar extends Module
{


    public function __construct()
    {
        $this->name = 'mfp_topinfobar';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Nice Code';
        $this->need_instance = 0;
        $this->_path = _PS_MODULE_DIR_.$this->name;
        $this->ps_versions_compliancy = [
            'min' => '1.7',
            'max' => '8.1.99',
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Top info bar');
        $this->description = $this->l('Module add top bar with information');

        $this->confirmUninstall = $this->confirmUninstall();

        if (!Configuration::get('SELECT ADD')) {
            $this->warning = $this->l('No name provided');
        }
    }
    public static function getPrefixDb() {

        return _DB_PREFIX_;
    }

    public function install()
    {

        if (!parent::install()) {
            return false;
        }
        if(!$this->registerHook('displayHeader')) return false;

        (new ManageSql())->installQuaries();


        return true;
    }
    public function confirmUninstall()
    {
        $this->context->smarty->assign(array(
            'module_display_name' => $this->displayName
        ));
//        echo $this->_path.'/views/templates/admin';
        return  $this->display(__FILE__, 'views/templates/admin/uninstall_popup.tpl');
    }
    public function uninstall()
    {
        // Deletes module tables


        if ($this->active) {

            $this->context->smarty->assign(array(
                'module_name' => $this->name,
                'module_display_name' => $this->displayName,
            ));

            $output = $this->display(__FILE__, 'uninstall_popup.tpl');
            $this->context->controller->addJqueryPlugin('fancybox');
            $this->context->controller->addCSS($this->_path.'views/css/uninstall_popup.css');
            $this->context->smarty->assign('module_display_name', $this->displayName);

            echo $output;
            return true;
        }
        (new ManageSql())->uninstallQueries();
        if (!parent::uninstall()) {
            return false;
        }
        return true;

    }

    public function getContent()
    {
        $output = '';
        $output .= (new ModulesForPrestaMarketing())->getRequaiermentsTemplate();
        return $output ;
    }

    public function hookDisplayHeader()
    {
        $link = new Link;
        $parameters_map = array("action" => "setinvoice");
        $ajax_get_map = $link->getModuleLink('mfp_switch_invoice', 'ajax', $parameters_map);

        Media::addJsDef(array(
            'ajax_get_map' => $ajax_get_map
        ));
        $this->context->controller->addJS($this->_path . 'views/js/main.js');
        $this->context->controller->addCSS($this->_path . 'views/css/main.css');
    }

}