<?php

require_once __DIR__.'/classes/ModulesForPrestaMarketing.php';
require_once __DIR__.'/classes/ModulesForPrestaConnector.php';
require_once __DIR__.'/classes/RegisterInPanelTab.php';
require_once __DIR__.'/classes/ManageSql.php';


if (!defined('_PS_VERSION_')) {
    exit;
}

class mfp_license_manager extends Module
{


    public function __construct()
    {
        $this->name = 'mfp_license_manager';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Modules for Presta';
        $this->need_instance = 0;
        $this->_path = _PS_MODULE_DIR_.$this->name;
        $this->ps_versions_compliancy = [
            'min' => '1.7',
            'max' => '8.1.99',
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('License manager');
        $this->description = $this->l('License manager');

//        $this->confirmUninstall = $this->confirmUninstall();

        if (!Configuration::get('SELECT ADD')) {
            $this->warning = $this->l('No name provided');
        }
    }
    public static function getPrefixDb() {

        return _DB_PREFIX_;
    }

    public function install()
    {

        if (!parent::install()) {
            return false;
        }
        if(!$this->registerHook('displayHeader')) return false;

        (new ManageSql())->installQuaries();

        $licenses_tab = new CustomMenuTab('Licencje modułów', 'mfp_license_manager', 999);
        $licenses_tab->addTab();
        $licenses_tab->addSubTab('Klienci z licencją', 'AdminModuleLicense', 1);
        $licenses_tab->addSubTab('Changelog', 'AdminChangelog', 2);

        $this->registerAllHooks(["displayHeader","actionOrderStatusUpdate"]);
        return true;
    }

    public function registerAllHooks($hooksArr){

        if(is_array($hooksArr)){
            foreach ($hooksArr as $hook){
                if(!$this->registerHook($hook)) return false;
            }
        }
        else
            return false;
    }

    public function confirmUninstall()
    {
        $this->context->smarty->assign(array(
            'module_display_name' => $this->displayName
        ));

        return  $this->display(__FILE__, 'views/templates/admin/uninstall_popup.tpl');
    }
    public function uninstall()
    {
        // Deletes module tables
        

        (new ManageSql())->uninstallQueries();
        if (!parent::uninstall()) {
            return false;
        }
        return true;

    }


    public function getContent()
    {
    }

    public function hookDisplayHeader()
    {

        $this->context->controller->addJS($this->_path . 'views/js/main.js');
        $this->context->controller->addCSS($this->_path . 'views/css/main.css');


    }
    public function hookActionOrderStatusUpdate($params)

    {


        $orderDetail = $this->getOrderValue($params["id_order"]);
        $database = Db::getInstance();
//        if( $settingsAdd["template"] == $orderDetail["currState"]['template']
//
//        ) {
//            $send = "minus";
//
//        }
//
//        if(
//
//            $settingsRemove["template"] == $orderDetail["currState"]['template']
//
//        ) {
//            $send = "plus";
//        }
    }




}