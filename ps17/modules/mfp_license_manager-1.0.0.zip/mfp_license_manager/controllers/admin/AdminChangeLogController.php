<?php
/**
 * LICENCE
 *
 * ALL RIGHTS RESERVED.
 * YOU ARE NOT ALLOWED TO COPY/EDIT/SHARE/WHATEVER.
 *
 * IN CASE OF ANY PROBLEM CONTACT AUTHOR.
 *
 *  @author    Modules for Presta (kontakt@modulesforpresta.com)
 *  @copyright modulesforpresta.com
 *  @license   ALL RIGHTS RESERVED
 */

class AdminChangeLogController extends ObjectModel
{



    /** @var int id category */
    public $id;

    /** @var int id module */
    public $module_id;

    /** @var string varsion */
    public $version;

    /** @var string content */
    public $content;

    /** @var string date */
    public $date;


    const TABLE_NAME = 'mfp_license_manager_change_log';

    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }



    /** @see ObjectModel::$definition */
    public static $definition = array(
        'table' => self::TABLE_NAME,
        'primary' => 'id',
        'fields' => array(
            'module_id' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'version' => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true),
            'content' => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true),
            'date' => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true),
        )
    );


}