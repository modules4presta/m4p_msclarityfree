<?php

/**
 * LICENCE
 *
 * ALL RIGHTS RESERVED.
 * YOU ARE NOT ALLOWED TO COPY/EDIT/SHARE/WHATEVER.
 *
 * IN CASE OF ANY PROBLEM CONTACT AUTHOR.
 *
 *  @author    Jakub Przepióra (kontakt@nice-code.eu)
 *  @copyright nice-code.pl
 *  @license   ALL RIGHTS RESERVED
 */


require_once __DIR__.'/classes/ModulesForPrestaMarketingAttachments_docs_order.php';
require_once __DIR__.'/classes/ManageSqlAttachments_docs_order.php';
require_once __DIR__.'/classes/RegisterInPanelTabAttachments_docs_order.php';


class mfp_attachments_docs_order extends Module
{


    public function __construct()
    {
        $this->name = 'mfp_attachments_docs_order';
        $this->tab = 'administration';
        $this->version = '1.0.4';
        $this->author = 'Modules for Presta';
        $this->need_instance = 0;
        $this->_path = _PS_MODULE_DIR_.$this->name;
        $this->ps_versions_compliancy = [
            'min' => '1.7.0.0',
            'max' => '8.1.99',
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Attachments documents');
        $this->description = $this->l('Module to attachments documents to order emails');



    }

    public function install()
    {


        // Instalacja bazy danych
        $manageSql = new ManageSqlAttachments_docs_order();
        if (!$manageSql->installQueries()) {
            return false;
        }

        if (!parent::install()) {
            return false;
        }

//        // Rejestracja zakładki
        $licenses_tab = new CustomMenuTabAttachmentsDocsOrder('Załączniki do emaila', 'mfp_attachments_docs_order', 0);
        $licenses_tab->addTab();
        $licenses_tab->addSubTab('Lista załączników', 'AdminModuleAttachmentsDocsOrder', 1);

        // Rejestracja hooków
        if (!$this->registerHook('actionValidateOrder')) {
            return false;
        }
        return true;
    }

    public function uninstall()
    {
        // Deletes module tables


        if (!parent::uninstall()) {
            return false;
        }
        if(!(new ManageSqlAttachments_docs_order())->uninstallQueries()) return false;

        return true;

    }
//    public function hookActionEmailSendBefore($params)
//    {
//
//        $attachments = Db::getInstance()->executeS(
//            'SELECT filename FROM `' . _DB_PREFIX_ . 'mfp_attachments_docs_order` WHERE active = 1'
//        );
//
//        if (!empty($attachments)) {
//            foreach ($attachments as $attachment) {
//                $filePath = _PS_UPLOAD_DIR_ . 'mfp_attachments_docs_order/' . $attachment['filename'];
//                if (file_exists($filePath)) {
//                    $attachmentData = array(
//                        'mime' => 'application/pdf',
//                        'content' => file_get_contents($filePath),
//                        'name' => $attachment['filename']
//                    );
//                    $params['attachment'][] = $attachmentData;
//                }
//            }
//        }
//        return $params;
//
//    }

//    public function hookActionValidateOrder($params)
//    {
//
//        $order = $params['order'];
//        $customer = new Customer($order->id_customer);
//
//        $pdfPath = _PS_MODULE_DIR_.'mfp_attachments_docs_order/uploads/68008264-4a776a00-fcb9-11e9-9e55-032e96e4c3af.png'; // Ścieżka do pliku PDF, który chcesz załączyć
//
//
//        $fileContent = file_get_contents($pdfPath);
//        $attachment = array(
//            'content' => $fileContent,
//            'name' => 'nazwa_pliku.pdf', // Nazwa pliku, pod którą ma być zapisany na komputerze klienta
//            'mime' => 'application/pdf'
//        );
//
//        $email = new Mail();
//        $email->subject = $this->l('Potwierdzenie zamówienia');
//        $email->template = 'order_conf';
//        $email->addAttachment($attachment['content'], $attachment['name'], $attachment['mime']);
//        $email->to = $customer->email;
//        $email->from = Configuration::get('PS_SHOP_EMAIL');
//        $email->fromName = Configuration::get('PS_SHOP_NAME');
//        $email->send();
//    }


}