<?php
/**
 * LICENCE
 *
 * ALL RIGHTS RESERVED.
 * YOU ARE NOT ALLOWED TO COPY/EDIT/SHARE/WHATEVER.
 *
 * IN CASE OF ANY PROBLEM CONTACT AUTHOR.
 *
 *  @author    Jakub Przepióra (kontakt@nice-code.eu)
 *  @copyright nice-code.pl
 *  @license   ALL RIGHTS RESERVED
 */



if (!defined('_PS_VERSION_')) {
    exit;
}

class m4p_download_only_register extends Module
{


    public function __construct()
    {
        $this->name = 'm4p_download_only_register';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Modules4Presta';
        $this->need_instance = 0;
        $this->_path = _PS_MODULE_DIR_.$this->name;
        $this->ps_versions_compliancy = [
            'min' => '1.7',
            'max' => '8.1.99',
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Download only register');
        $this->description = $this->l('License manager');

//        $this->confirmUninstall = $this->confirmUninstall();

        if (!Configuration::get('SELECT ADD')) {
            $this->warning = $this->l('No name provided');
        }
    }
    public static function getPrefixDb() {

        return _DB_PREFIX_;
    }

    public function install()
    {

        if (!parent::install()) {
            return false;
        }


        $this->registerAllHooks(["displayHeader","displayOverrideTemplate"]);
        return true;
    }

    public function registerAllHooks($hooksArr){

        if(is_array($hooksArr)){
            foreach ($hooksArr as $hook){
                if(!$this->registerHook($hook)) return false;
            }
        }
        else
            return false;
    }


    public function uninstall()
    {
        // Deletes module tables
        

        (new ManageSql())->uninstallQueries();
        if (!parent::uninstall()) {
            return false;
        }
        return true;

    }
    public function hookDisplayOverrideTemplate($params)
    {
        if (!$this->context->customer->isLogged()) {

            $template = $params['template'];

            if ($template === 'product-add-to-cart.tpl') {
                return $this->fetch('module:m4p_download_only_register/views/templates/override/product_registration_button.tpl');
            }
        }

        // Zwróć null, aby kontynuować normalne wyświetlanie szablonu
        return null;
    }

    public function hookDisplayHeader()
    {
        $link = new Link;
        $parameters_ads_module = array("action" => "ajax");
        $ajax_get_ads = $link->getModuleLink('mfp_license_manager', 'ajax', $parameters_ads_module);
        var_dump($ajax_get_ads);
        $this->context->controller->addJS($this->_path . 'views/js/main.js');
        $this->context->controller->addCSS($this->_path . 'views/css/main.css');
        $this->registerHook("displayAdditionalCustomerAddressFields");


    }

    public function hookDisplayAdditionalCustomerAddressFields($params)
    {
        $this->context->smarty->assign(array(
            'additional_info_label' => $this->l('Additional information'),
        ));
        var_dump("dasdasdasdas");
        return $this->display(__FILE__, 'views/templates/hooks/displayCustomerAddressForm.tpl');
    }



}