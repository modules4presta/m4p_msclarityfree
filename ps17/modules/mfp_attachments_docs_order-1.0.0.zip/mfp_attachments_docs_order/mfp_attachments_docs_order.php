<?php

/**
 * LICENCE
 *
 * ALL RIGHTS RESERVED.
 * YOU ARE NOT ALLOWED TO COPY/EDIT/SHARE/WHATEVER.
 *
 * IN CASE OF ANY PROBLEM CONTACT AUTHOR.
 *
 *  @author    Jakub Przepióra (kontakt@nice-code.eu)
 *  @copyright nice-code.pl
 *  @license   ALL RIGHTS RESERVED
 */


require_once __DIR__.'/classes/ModulesForPrestaMarketingAttachments_docs_order.php';
require_once __DIR__.'/classes/ManageSqlAttachments_docs_order.php';
require_once __DIR__.'/classes/RegisterInPanelTabAttachments_docs_order.php';


if (!defined('_PS_VERSION_')) {
    exit;
}

class mfp_attachments_docs_order extends Module
{


    public function __construct()
    {
        $this->name = 'mfp_attachments_docs_order';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Modules for Presta';
        $this->need_instance = 0;
        $this->_path = _PS_MODULE_DIR_.$this->name;
        $this->ps_versions_compliancy = [
            'min' => '1.7',
            'max' => '8.1.99',
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Attachments documents');
        $this->description = $this->l('Module to attachments documents to order emails');



    }

    public function install()
    {

        if (!parent::install()) {
            return false;
        }
        // install database
        if(!(new ManageSqlAttachments_docs_order())->installQuaries()) return false;

        if(!$this->registerHook('displayHeader')) return false;
        if(!$this->registerHook('actionFrontControllerSetMedia')) return false;

        // register tab
        $licenses_tab = new CustomMenuTabAttachmentsDocsOrder('Załączniki do emaila', 'mfp_attachments_docs_order', 0);
        $licenses_tab->addTab();
        $licenses_tab->addSubTab('Lista załączników', 'AdminModuleAttachmentsDocsOrder', 1);

        return true;
    }

    public function uninstall()
    {
        // Deletes module tables


        if (!parent::uninstall()) {
            return false;
        }
        if(!(new ManageSqlAttachments_docs_order())->uninstallQueries()) return false;

        return true;

    }


}