$(document).on('change', '.js-cart-line-product-quantity', function() {

    var productId = $(this).data('product-id');
    // var newQuantity = $(this).val();
    // Wyślij żądanie AJAX do zaktualizowania zawartości TPL
    const curr_cart_id = $("#currently_cart_id").val();
    $.ajax({
        url: addtofreedelivery.ajax_addtofreedelivery,
        type: 'POST',
        data: {
            productId: productId,
            // newQuantity: newQuantity,
            rerenderCart: 1,
            cartId: curr_cart_id
        },
        success: function(response) {
            document.getElementById("list_product_addtofreedelivery").innerHTML="";
            // console.log(response.list_prod);
            // let res = JSON.parse(response);
            document.getElementById("list_product_addtofreedelivery").innerHTML=response;
        },
        error: function(xhr, textStatus, errorThrown) {
            console.log('Wystąpił błąd podczas żądania AJAX: ' + errorThrown);
        }
    });
});
$(document).on('click', '.remove-from-cart', function() {

    var productId = $(this).data('product-id');
    // var newQuantity = $(this).val();
    // Wyślij żądanie AJAX do zaktualizowania zawartości TPL
    const curr_cart_id = $("#currently_cart_id").val();
    $.ajax({
        url: addtofreedelivery.ajax_addtofreedelivery,
        type: 'POST',
        data: {
            productId: productId,
            // newQuantity: newQuantity,
            rerenderCart: 1,
            cartId: curr_cart_id
        },
        success: function(response) {
            document.getElementById("list_product_addtofreedelivery").innerHTML="";
            // console.log(response.list_prod);
            // let res = JSON.parse(response);
            document.getElementById("list_product_addtofreedelivery").innerHTML=response;
        },
        error: function(xhr, textStatus, errorThrown) {
            console.log('Wystąpił błąd podczas żądania AJAX: ' + errorThrown);
        }
    });
});
