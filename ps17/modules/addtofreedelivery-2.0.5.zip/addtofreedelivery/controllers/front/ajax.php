<?php


require_once _PS_MODULE_DIR_.'addtofreedelivery/controllers/admin/AdminAddToFreeDeliveryController.php';
require_once _PS_MODULE_DIR_.'addtofreedelivery/classes/FreeShippingProducts.php';
class AddtofreedeliveryAjaxModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        if(Tools::getValue('q')){
            // Usefull vars derivated from getContext
            $context = Context::getContext();

            // Get the search term from the request
            $searchTerm = Tools::getValue('q');

            // Minimum length of the search term
            $minLength = 3;

            // Check if the search term meets the minimum length requirement

            if (strlen($searchTerm) >= $minLength) {

                // Get the categories that match the search term
                $categories = Product::searchByName($context->language->id, $searchTerm);

                // Format the categories as an array of JSON objects
                $categoryList = array();
                if(empty($categories)) exit;
                foreach ($categories as $category) {
                    $categoryList[] = array(
                        'id' => $category['id_product'],
                        'name' => $category['name'],

                    );
                    echo $category['id_product'].'-'. $category['name']."\n";
                }


            }
            die();
        }

        if(Tools::getValue('rerenderCart')) {

            error_reporting(0);

            sleep(2);

            $quantity = $display_product = Configuration::get('PS_DISPLAY_PRODUCT');
            $margin_price_percent = Configuration::get('PS_MARGIN_PRICE_PERCENT');

            $productsSetGet = Configuration::get('PS_PRODUCTS_SELECT');
            $productsSet = [];
            $curr_cart_id = Tools::getValue("cartId");

            if (!empty($productsSetGet)){

                $productsSetRaw = explode('-', $productsSetGet);
                foreach ($productsSetRaw as $item) {
                    if($item != '') {
                        $productsSet[] = $item;
                    }
                }
            }

            $categorySet = Configuration::get('PS_CATEGORY_SELECT');
            if (empty($categorySet)){
                $categorySet = [];
            }else{
                $categorySet = explode('-', $categorySet);
            }

            $shippingModel = new FreeShippingProducts();
            $totalFreeShipping = $shippingModel->getTotalFreeShipping();
            $totalFreeShippingMargin = $totalFreeShipping;
            $totalFreeShippingMin = $totalFreeShipping;
            if (isset($margin_price_percent) && $margin_price_percent){
                $totalFreeShippingMargin = $totalFreeShipping *  ((100 + $margin_price_percent) / 100);
            }

            $products = $shippingModel->getProducts($totalFreeShippingMin, $totalFreeShippingMargin, $quantity, $categorySet, $productsSet);

            $this->context = Context::getContext();
            $currency = new Currency((int)$this->context->cart->id_currency);
            $this->context->smarty->assign([
                'currently_cart_id' => $curr_cart_id,
                'priceToFreeDelivery' => $totalFreeShipping,
                'priceToFreeDeliveryWithCurrency' => $totalFreeShipping." ".$currency->iso_code,
                'freeShippingProductListDir' => dirname(__FILE__),
                'freeShippingProducts' => isset($products) && !empty($products) ? array_map(array($this, 'prepareProductForTemplate'), $products) : null,
            ]);


            $this->setTemplate('module:addtofreedelivery/views/templates/freeshippingproduct80.tpl');

        }

    }



    private function prepareProductForTemplate(array $rawProduct)
    {
        $product = (new ProductAssembler($this->context))
            ->assembleProduct($rawProduct)
        ;

        $presenter = $this->getProductPresenter();
        $settings = $this->getProductPresentationSettings();

        return $presenter->present(
            $settings,
            $product,
            $this->context->language
        );
    }
    private function getFactory()
    {
        return new ProductPresenterFactory($this->context, new TaxConfiguration());
    }

    protected function getProductPresentationSettings()
    {
        return $this->getFactory()->getPresentationSettings();
    }

    protected function getProductPresenter()
    {
        return $this->getFactory()->getPresenter();
    }
}

