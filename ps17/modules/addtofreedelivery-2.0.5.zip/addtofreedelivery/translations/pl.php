<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{addtofreedelivery}prestashop>addtofreedelivery_a4bf477e0136caf22f9d861c458c0ef5'] = 'Niepoprawna wartość dla darmowej dostawy';
$_MODULE['<{addtofreedelivery}prestashop>addtofreedelivery_dc03eca386783a34de2e36241e732b10'] = 'Niepoprawna wartość dla marzy';
$_MODULE['<{addtofreedelivery}prestashop>addtofreedelivery_543f6c4aa463425555e24510b3e3002d'] = 'Niepoprawna wartość dla ilość wyświetlanych produktów';
$_MODULE['<{addtofreedelivery}prestashop>freeshippingproduct80_17590288f54116c8428758f16763382e'] = 'Do darmowej wysyłki brakuje: ';
$_MODULE['<{addtofreedelivery}prestashop>freeshippingproduct80_0cd198f4a4e94182873bae3a89b83e7d'] = 'Dodaj produkty do swojego zamówienia aby otrzymać darmową dostawę';
$_MODULE['<{addtofreedelivery}prestashop>freeshippingproduct17_17590288f54116c8428758f16763382e'] = 'Do darmowej dostary brakuje';
$_MODULE['<{addtofreedelivery}prestashop>freeshippingproduct17_0cd198f4a4e94182873bae3a89b83e7d'] = 'Dobierz produkty do swokego zamówienia, aby otrzymać darmową dostawe';
$_MODULE['<{addtofreedelivery}prestashop>freeshippingproducts_17590288f54116c8428758f16763382e'] = 'Do darmowej dostary brakuje';
$_MODULE['<{addtofreedelivery}prestashop>freeshippingproducts_0cd198f4a4e94182873bae3a89b83e7d'] = 'Dobierz produkty do swokego zamówienia, aby otrzymać darmową dostawe';
$_MODULE['<{addtofreedelivery}prestashop>form_326edd22eb7d44c5ffbc2359c4a8fd13'] = 'Używane kategorie:';
$_MODULE['<{addtofreedelivery}prestashop>form_78587049e12fb4f6b12e2bb045f2880a'] = 'Wybór kategorii jest wyłaczony ponieważ nie masz kategorii lub jesteś w \"Wszystkie sklepy\" jeżeli używasz opcji Multistore';
$_MODULE['<{addtofreedelivery}prestashop>form_175c4f2321b7c89d71892a0bd29d0bb2'] = 'Używane produkty:';
$_MODULE['<{addtofreedelivery}prestashop>form_7fdfa5d471b91b04fe1b3b34ba742e3b'] = 'Darmowa dostawa:';
$_MODULE['<{addtofreedelivery}prestashop>form_3383c2a0576fbb933be13f47be0097b1'] = 'Ilość wyświetlanych produktów';
$_MODULE['<{addtofreedelivery}prestashop>form_9931af9ee694c155c51a416623a2dc62'] = 'Margines procentowy różnicy cenowych';
$_MODULE['<{addtofreedelivery}prestashop>form_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{addtofreedelivery}prestashop>form_ea4788705e6873b424c65e91c2846b19'] = 'Anuluj';
